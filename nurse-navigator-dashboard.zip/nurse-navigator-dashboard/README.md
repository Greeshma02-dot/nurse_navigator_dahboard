# Nurse Navigator Auto-Sync Dashboard

## 🚀 1-Click Deploy to Vercel

### Method 1: Deploy Button (EASIEST)

Click this button to deploy:

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/YOUR-USERNAME/nurse-navigator-dashboard)

### Method 2: Manual Deploy

1. Download all files from this folder
2. Go to https://vercel.com
3. Sign up (free)
4. Click "Add New Project"
5. Click "Import"
6. Drag and drop this entire folder
7. Click "Deploy"
8. Wait 2 minutes
9. DONE! You get a live URL!

## 📋 After Deployment

You'll get a URL like: `https://nurse-navigator-xxxxx.vercel.app`

This is your live dashboard!

## ⚡ Setting Up Auto-Sync

After deploying, you need to connect Power Automate:

1. Save Excel in OneDrive
2. Create Power Automate flow (see POWER_AUTOMATE_SETUP.md)
3. Point it to your Vercel URL: `https://your-url.vercel.app/api/nurse-navigator-data`
4. Done! Auto-updates every 5-10 minutes

## 🎯 What You Get

- ✅ Live dashboard URL
- ✅ Auto-updates from Excel
- ✅ Professional interface
- ✅ FREE hosting
- ✅ No maintenance needed

## 📞 Next Steps

1. Deploy this to Vercel (2 minutes)
2. Get your URL
3. Set up Power Automate (15 minutes)
4. Test with Excel file
5. Share URL with Rebecca!
